"""
alerts/alert_manager.py
------------------------
Central place that fires off an alert once the pipeline decides a
situation is a threat (e.g. weapon detected + following behavior).

Channels implemented:
  1. Console print            -- always on, zero dependencies
  2. Terminal beep "sound"    -- cross-platform, no audio libs required
  3. HTTP POST to Flask API   -- server/app.py's /alert endpoint
  4. Twilio SMS (optional)    -- stubbed out, fill in credentials to enable

A simple cooldown prevents spamming the same alert every single frame.
"""

import time
import requests

DEFAULT_SERVER_URL = "http://127.0.0.1:5000/alert"


class AlertManager:
    def __init__(self, server_url=DEFAULT_SERVER_URL, cooldown_seconds=8,
                 enable_sound=True, enable_http=True, enable_sms=False):
        self.server_url = server_url
        self.cooldown_seconds = cooldown_seconds
        self.enable_sound = enable_sound
        self.enable_http = enable_http
        self.enable_sms = enable_sms
        self._last_alert_time = 0

    def _cooldown_ok(self):
        return (time.time() - self._last_alert_time) >= self.cooldown_seconds

    def trigger(self, alert_type, details=None):
        """
        alert_type: short string, e.g. "WEAPON_DETECTED", "FOLLOWING_BEHAVIOR",
                    "WEAPON_PLUS_FOLLOWING"
        details: dict with extra context (track ids, confidence, etc.)
        """
        if not self._cooldown_ok():
            return  # skip, we alerted very recently

        self._last_alert_time = time.time()
        details = details or {}
        payload = {
            "type": alert_type,
            "timestamp": time.time(),
            "details": details,
        }

        self._console_alert(alert_type, details)
        if self.enable_sound:
            self._sound_alert()
        if self.enable_http:
            self._http_alert(payload)
        if self.enable_sms:
            self._sms_alert(alert_type, details)

    # ---- individual channels -------------------------------------------------

    def _console_alert(self, alert_type, details):
        print(f"\n🚨 [ALERT] {alert_type} -- {details}\n")

    def _sound_alert(self):
        """Cross-platform terminal bell. Swap for `playsound('alarm.wav')`
        if you add the `playsound` package and an audio file."""
        try:
            print("\a", end="", flush=True)  # ASCII bell character
        except Exception:
            pass

    def _http_alert(self, payload):
        """POST the alert to the Flask backend so the dashboard can show it."""
        try:
            requests.post(self.server_url, json=payload, timeout=1.5)
        except requests.exceptions.RequestException as e:
            print(f"[alert_manager] Could not reach backend ({self.server_url}): {e}")

    def _sms_alert(self, alert_type, details):
        """
        Optional Twilio SMS integration. Fill in your credentials and
        uncomment to enable. Left disabled by default so the project runs
        with zero paid services.
        """
        # from twilio.rest import Client
        # account_sid = "YOUR_TWILIO_SID"
        # auth_token = "YOUR_TWILIO_AUTH_TOKEN"
        # client = Client(account_sid, auth_token)
        # client.messages.create(
        #     body=f"Security Alert: {alert_type} - {details}",
        #     from_="+1XXXXXXXXXX",       # your Twilio number
        #     to="+91XXXXXXXXXX",         # destination number
        # )
        print("[alert_manager] SMS alert would be sent here (Twilio not configured).")
