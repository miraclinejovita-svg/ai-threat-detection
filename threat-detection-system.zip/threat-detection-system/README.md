# 🛡️ AI-Based Threat Detection System using CCTV and WiFi Tracking

Real-time detection of suspicious behavior — a person following another,
someone carrying a knife, or both together — using a normal laptop
webcam or an RTSP CCTV stream. No GPU required.

---

## 1. Project Overview

| Layer | What it does | Tech |
|---|---|---|
| **Detection** | Finds people + knives in each frame | YOLOv8n (`ultralytics`), OpenCV |
| **Tracking** | Gives every person a stable ID across frames | ByteTrack (built into `ultralytics`) |
| **Behavior** | Flags "Person A is following Person B" | Centroid distance + frame-streak logic |
| **Weapon Logic** | Flags knife detections, escalates if combined with following | YOLO knife class (COCO class 43) |
| **Alerts** | Console, terminal beep, HTTP POST, optional SMS | `requests`, optional `twilio` |
| **Backend API** | Receives/stores alerts, serves dashboard | Flask |
| **WiFi Tracking** | Simulated/real nearby-device sightings, privacy-hashed | Scapy (real) / built-in simulator |
| **Dashboard** | Live annotated feed + alert table + tracked persons | Flask + HTML/JS |

**Why no custom training is needed:** the stock `yolov8n.pt` weights are
trained on COCO, which already includes both a `person` class and a
`knife` class — so weapon detection works out of the box for a demo.
For production accuracy you'd fine-tune on a dedicated weapons dataset.

---

## 2. Folder Structure

```
threat-detection-system/
├── main.py                      # CLI entry point: full pipeline on webcam/RTSP
├── requirements.txt
├── README.md
│
├── detection/
│   ├── __init__.py
│   └── detector.py              # YOLOv8 detection + ByteTrack tracking + drawing
│
├── tracking/
│   ├── __init__.py
│   └── tracker.py                # Per-ID centroid history buffer
│
├── behavior/
│   ├── __init__.py
│   └── behavior_analyzer.py      # "Following" detection logic
│
├── wifi/
│   ├── __init__.py
│   └── wifi_scanner.py           # Scapy probe-request sniffing + simulator
│
├── alerts/
│   ├── __init__.py
│   └── alert_manager.py          # Console / sound / HTTP / SMS alert dispatch
│
└── server/
    ├── __init__.py
    ├── app.py                    # Flask API (/alert, /alerts) + dashboard + live feed
    └── templates/
        └── dashboard.html
```

---

## 3. Installation

**Requirements:** Python 3.9+, a webcam (or an RTSP URL), no GPU needed.

```bash
# 1. Clone / unzip the project, then cd into it
cd threat-detection-system

# 2. Create a virtual environment (recommended)
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt
```

The first time you run detection, `ultralytics` will auto-download
`yolov8n.pt` (~6 MB) — you need internet access for that one-time step.

> **Note on Scapy/WiFi module:** real WiFi sniffing needs a monitor-mode
> capable adapter and root/admin privileges, and won't work on most
> laptops out of the box (especially Windows). The project defaults to
> **simulated mode**, which needs nothing extra and demonstrates the same
> hashing/logging pipeline. See `wifi/wifi_scanner.py` for how to switch
> to real sniffing on Linux.

---

## 4. How to Run

### Option A — Full demo with web dashboard (recommended for hackathon judges)

```bash
python server/app.py
```

Then open **http://127.0.0.1:5000** in a browser. You'll see:
- a live annotated camera feed (green = person, red = suspicious/following, orange = knife)
- a live-updating table of alerts
- currently tracked person IDs

This single command runs its own internal detection pipeline — you don't
need to run `main.py` separately for this.

### Option B — CLI-only pipeline (a local OpenCV window, no web dashboard)

```bash
python main.py
```

Optional flags:
```bash
python main.py --source 1                        # use a different webcam
python main.py --source "rtsp://user:pass@ip/stream"   # use a real CCTV/RTSP feed
python main.py --no-window                        # headless mode (server/embedded use)
python main.py --distance 150 --frames 30          # tune "following" sensitivity
```

Press **`q`** in the video window to quit.

If `server/app.py` is also running in another terminal, `main.py` will
POST alerts to it automatically so they show up on the dashboard too.

### Option C — Try the WiFi module standalone

```bash
python wifi/wifi_scanner.py
```

Prints simulated device sightings once a second and logs hashed MACs to
`wifi/wifi_log.csv`.

---

## 5. Tuning the "Following" Behavior Detector

In `behavior/behavior_analyzer.py` (or via `main.py` flags):

- `distance_threshold` (pixels): how close two people's centroids must be
  to count as "close". Lower = stricter, avoids false positives from
  people who are just far apart in frame but happen to walk the same way.
- `frames_required`: how many *consecutive* close frames before it's
  flagged suspicious rather than a coincidental crossing. At ~30 fps,
  `20` frames ≈ 0.6 seconds; raise this for a busier scene.

---

## 6. Future Improvements

- Fine-tune YOLOv8 on a dedicated weapons dataset (knives, guns) for
  higher accuracy than the generic COCO `knife` class.
- Replace centroid-distance "following" logic with trajectory/velocity
  matching (two people moving in the same direction at matching speed
  is a much stronger signal than raw proximity).
- Persist alerts to a real database (SQLite/Postgres) instead of an
  in-memory list, and add authentication to the dashboard.
- Correlate WiFi device dwell-time with vision-based loitering/following
  alerts for stronger multi-modal confidence scoring.
- Add real Twilio SMS / email notifications for confirmed high-severity alerts.
- Multi-camera support: run one pipeline per RTSP stream and aggregate
  alerts centrally in the Flask backend.
- Re-identification (ReID) so a person who leaves and re-enters frame
  keeps the same ID, rather than getting a new one from ByteTrack.

---

## Disclaimer

This is a hackathon/educational prototype. Detection accuracy depends on
camera angle, lighting, and occlusion — it is **not** a certified security
product and shouldn't be relied on as the sole safety measure in a real
deployment.
