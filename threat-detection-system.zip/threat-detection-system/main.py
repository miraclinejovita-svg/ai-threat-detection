"""
main.py
-------
Standalone CLI entry point for the AI-Based Threat Detection System.

Opens a webcam (or RTSP CCTV stream), runs YOLOv8 detection + ByteTrack
tracking on every frame, analyzes movement for "following" behavior,
checks for weapons (knives), and fires alerts (console + sound + HTTP to
the Flask backend) when a threat pattern is found. Shows an annotated
window so you can see detections live.

USAGE:
    python main.py                       # use default webcam (index 0)
    python main.py --source 1            # use a different webcam index
    python main.py --source "rtsp://..." # use an RTSP CCTV stream
    python main.py --no-window           # run headless (no cv2.imshow)

While this runs, you can optionally also run `python server/app.py` in a
separate terminal to see alerts land on the web dashboard in real time
(main.py POSTs to it automatically; if it's not running, alerts just get
skipped for that channel and everything else still works).
"""

import argparse
import time

import cv2

from detection.detector import ThreatDetector
from tracking.tracker import TrackHistory
from behavior.behavior_analyzer import BehaviorAnalyzer
from alerts.alert_manager import AlertManager
from wifi.wifi_scanner import WifiScanner


def parse_args():
    parser = argparse.ArgumentParser(description="AI-Based Threat Detection System")
    parser.add_argument("--source", default=0,
                         help="Video source: webcam index (0,1,...) or RTSP/video URL")
    parser.add_argument("--conf", type=float, default=0.4, help="YOLO confidence threshold")
    parser.add_argument("--distance", type=int, default=120,
                         help="Pixel distance threshold for 'close' people")
    parser.add_argument("--frames", type=int, default=20,
                         help="Consecutive close frames required to flag 'following'")
    parser.add_argument("--no-window", action="store_true", help="Run headless, no display window")
    parser.add_argument("--no-wifi", action="store_true", help="Disable simulated WiFi module")
    parser.add_argument("--server-url", default="http://127.0.0.1:5000/alert",
                         help="Flask backend /alert endpoint")
    return parser.parse_args()


def main():
    args = parse_args()

    # Video source can be an int (webcam index) or a string (RTSP/file url)
    source = args.source
    try:
        source = int(source)
    except (TypeError, ValueError):
        pass  # keep as string (RTSP URL / file path)

    print(f"[main] Opening video source: {source}")
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        print(f"[main] ERROR: could not open video source '{source}'. "
              f"Check your webcam index or RTSP URL.")
        return

    detector = ThreatDetector(model_path="yolov8n.pt", conf_threshold=args.conf)
    history = TrackHistory()
    behavior = BehaviorAnalyzer(distance_threshold=args.distance, frames_required=args.frames)
    alert_manager = AlertManager(server_url=args.server_url)
    wifi_scanner = None if args.no_wifi else WifiScanner(simulate=True)

    last_wifi_scan = 0
    frame_count = 0
    t_start = time.time()

    print("[main] Pipeline running. Press 'q' in the video window to quit "
          "(or Ctrl+C in headless mode).")

    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                print("[main] Frame grab failed / stream ended.")
                break

            frame_count += 1

            # 1. Detection + tracking -----------------------------------------
            detections = detector.detect_and_track(frame)
            history.update(detections)

            # 2. Behavior analysis ("following") -------------------------------
            suspicious_pairs, suspicious_ids = behavior.analyze(detections)

            # 3. Weapon check ---------------------------------------------------
            weapon_detections = [d for d in detections if d["cls_name"] == "knife"]
            weapon_present = len(weapon_detections) > 0

            # 4. Simulated WiFi sighting (roughly once a second) ----------------
            if wifi_scanner and (time.time() - last_wifi_scan) > 1.0:
                wifi_scanner.simulate_once()
                last_wifi_scan = time.time()

            # 5. Decide + fire alerts --------------------------------------------
            if weapon_present and suspicious_pairs:
                alert_manager.trigger("WEAPON_PLUS_FOLLOWING", {
                    "person_pairs": list(suspicious_pairs),
                    "weapon_confidences": [d["conf"] for d in weapon_detections],
                })
            elif weapon_present:
                alert_manager.trigger("WEAPON_DETECTED", {
                    "weapon_confidences": [d["conf"] for d in weapon_detections],
                })
            elif suspicious_pairs:
                alert_manager.trigger("FOLLOWING_BEHAVIOR", {
                    "person_pairs": list(suspicious_pairs),
                })

            # 6. Display -----------------------------------------------------------
            if not args.no_window:
                annotated = detector.annotate_frame(
                    frame, detections, suspicious_ids=suspicious_ids, weapon_present=weapon_present
                )
                fps = frame_count / max(time.time() - t_start, 1e-6)
                cv2.putText(annotated, f"FPS: {fps:.1f}", (20, annotated.shape[0] - 15),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                cv2.imshow("AI Threat Detection - press q to quit", annotated)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break

    except KeyboardInterrupt:
        print("\n[main] Stopped by user.")
    finally:
        cap.release()
        cv2.destroyAllWindows()
        print("[main] Shutdown complete.")


if __name__ == "__main__":
    main()
