"""
behavior/behavior_analyzer.py
------------------------------
Implements the "following behavior" detection logic:

    If Person A stays within DISTANCE_THRESHOLD pixels of Person B for
    FRAMES_REQUIRED consecutive frames -> flag the pair as suspicious.

This is intentionally simple (centroid Euclidean distance) so it's easy
to understand and tune for a hackathon demo, but the structure makes it
straightforward to swap in a smarter metric later (e.g. normalized by
bounding-box size / camera distance, or actual walking-speed matching).
"""

import math
from collections import defaultdict


class BehaviorAnalyzer:
    def __init__(self, distance_threshold=120, frames_required=20):
        """
        distance_threshold: max pixel distance between two people's
                             centroids to be considered "close".
        frames_required: how many consecutive close frames before we
                          call it "following" rather than a coincidence
                          (e.g. two people briefly crossing paths).
        """
        self.distance_threshold = distance_threshold
        self.frames_required = frames_required

        # (idA, idB) -> consecutive close-frame count
        self._close_streak = defaultdict(int)
        # set of (idA, idB) pairs currently flagged suspicious
        self.suspicious_pairs = set()

    @staticmethod
    def _distance(p1, p2):
        return math.hypot(p1[0] - p2[0], p1[1] - p2[1])

    def analyze(self, detections):
        """
        detections: current frame's detection list (from ThreatDetector).
        Returns: set of suspicious pairs, and set of individual person IDs
                 involved in any suspicious pair (handy for highlighting).
        """
        people = [d for d in detections if d["cls_name"] == "person" and d["id"] != -1]

        seen_pairs_this_frame = set()

        # Compare every pair of currently-visible people
        for i in range(len(people)):
            for j in range(i + 1, len(people)):
                a, b = people[i], people[j]
                pair = tuple(sorted((a["id"], b["id"])))
                dist = self._distance(a["centroid"], b["centroid"])

                if dist <= self.distance_threshold:
                    self._close_streak[pair] += 1
                    seen_pairs_this_frame.add(pair)
                else:
                    self._close_streak[pair] = 0
                    self.suspicious_pairs.discard(pair)

                if self._close_streak[pair] >= self.frames_required:
                    self.suspicious_pairs.add(pair)

        # Reset streaks for pairs that weren't both visible this frame
        for pair in list(self._close_streak.keys()):
            if pair not in seen_pairs_this_frame:
                self._close_streak[pair] = 0
                self.suspicious_pairs.discard(pair)

        suspicious_ids = set()
        for a, b in self.suspicious_pairs:
            suspicious_ids.add(a)
            suspicious_ids.add(b)

        return self.suspicious_pairs, suspicious_ids
