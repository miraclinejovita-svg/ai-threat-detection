"""
tracking/tracker.py
--------------------
The actual frame-to-frame ID assignment is handled by YOLOv8's built-in
ByteTrack tracker inside detection/detector.py (satisfies the "use
DeepSORT or ByteTrack" requirement with zero extra heavyweight
dependencies -- ByteTrack ships inside `ultralytics`).

This module is the second half of tracking: it stores a short *history*
of centroid positions for every track ID across recent frames. The
behavior module then reads this history to reason about movement
patterns (e.g. "has person #5 been near person #2 for the last 30
frames?").

Keeping this as its own module (rather than stuffing it into the
detector) keeps responsibilities clean:
    detector.py -> "what is in this frame, and what ID is it"
    tracker.py  -> "where has this ID been recently"
    behavior.py -> "does that movement pattern look suspicious"
"""

from collections import deque, defaultdict
import time


class TrackHistory:
    """Keeps a rolling window of (timestamp, centroid, cls_name) per track ID."""

    def __init__(self, max_history=60, stale_after_seconds=5.0):
        """
        max_history: how many past positions to remember per ID.
        stale_after_seconds: forget an ID if it hasn't been seen this long
                              (handles people/objects leaving the frame).
        """
        self.max_history = max_history
        self.stale_after_seconds = stale_after_seconds
        self._history = defaultdict(lambda: deque(maxlen=max_history))
        self._last_seen = {}
        self._cls_name = {}

    def update(self, detections):
        """Feed the latest frame's detections into the history buffers."""
        now = time.time()
        for det in detections:
            track_id = det["id"]
            if track_id == -1:
                continue  # untracked detection, nothing to store
            self._history[track_id].append((now, det["centroid"]))
            self._last_seen[track_id] = now
            self._cls_name[track_id] = det["cls_name"]

        self._evict_stale(now)

    def _evict_stale(self, now):
        """Remove IDs that haven't been seen recently to save memory."""
        stale_ids = [
            tid for tid, ts in self._last_seen.items()
            if now - ts > self.stale_after_seconds
        ]
        for tid in stale_ids:
            self._history.pop(tid, None)
            self._last_seen.pop(tid, None)
            self._cls_name.pop(tid, None)

    def get_history(self, track_id):
        """Return the deque of (timestamp, centroid) for a given track ID."""
        return self._history.get(track_id, deque())

    def active_person_ids(self):
        """Return IDs currently tracked whose class is 'person'."""
        return [tid for tid, name in self._cls_name.items() if name == "person"]

    def latest_centroid(self, track_id):
        hist = self._history.get(track_id)
        if not hist:
            return None
        return hist[-1][1]
