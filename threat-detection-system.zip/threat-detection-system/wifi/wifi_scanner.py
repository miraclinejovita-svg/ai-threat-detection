"""
wifi/wifi_scanner.py
---------------------
Basic WiFi presence-tracking module.

Real mode:
    Uses Scapy to sniff 802.11 probe-request frames (the packets phones
    send out constantly while looking for known networks). Every nearby
    phone/laptop with WiFi on will appear here, giving a rough sense of
    "how many devices / how long have they lingered" near the camera --
    conceptually useful alongside the CCTV behavior module (e.g. a
    device that lingers near the entrance for a long time correlates
    with a loitering/following alert from the vision pipeline).

    NOTE: this requires a WiFi adapter capable of monitor mode, root/
    admin privileges, and is OS-dependent (Linux is easiest, e.g.
    `sudo airmon-ng start wlan0` first). Most laptops (esp. Windows/WSL)
    will NOT support this out of the box -- that's expected.

Simulated mode (default, and what most people will actually run):
    Generates believable fake MAC addresses on an interval, so the rest
    of the pipeline (hashing, logging, dashboard integration) can be
    demoed on any laptop with zero special hardware.

Privacy: raw MAC addresses are never stored -- they are SHA-256 hashed
immediately, so the log can't be used to directly re-identify a device.
"""

import hashlib
import random
import time
import csv
import os

LOG_PATH = os.path.join(os.path.dirname(__file__), "wifi_log.csv")


def hash_mac(mac: str) -> str:
    """One-way hash a MAC address for privacy-preserving logging."""
    return hashlib.sha256(mac.lower().encode()).hexdigest()[:16]


def _ensure_log_header():
    if not os.path.exists(LOG_PATH):
        with open(LOG_PATH, "w", newline="") as f:
            csv.writer(f).writerow(["timestamp", "hashed_mac", "rssi"])


def _log_sighting(hashed_mac, rssi=None):
    _ensure_log_header()
    with open(LOG_PATH, "a", newline="") as f:
        csv.writer(f).writerow([time.time(), hashed_mac, rssi if rssi is not None else ""])


class WifiScanner:
    def __init__(self, interface=None, simulate=True):
        """
        interface: monitor-mode WiFi interface name (e.g. 'wlan0mon').
                   Ignored in simulate mode.
        simulate:  if True (default), fakes device sightings instead of
                   requiring real monitor-mode hardware.
        """
        self.interface = interface
        self.simulate = simulate
        self.seen_devices = {}  # hashed_mac -> {first_seen, last_seen, count}

    # ---- real mode -------------------------------------------------------

    def _handle_packet(self, pkt):
        try:
            from scapy.layers.dot11 import Dot11ProbeReq
        except ImportError:
            return
        if pkt.haslayer(Dot11ProbeReq):
            mac = pkt.addr2
            if not mac:
                return
            hashed = hash_mac(mac)
            self._record_sighting(hashed)

    def start_real_sniff(self, timeout=None):
        """Blocking call: sniffs real 802.11 probe requests. Requires
        monitor mode + root privileges. See module docstring."""
        from scapy.all import sniff
        print(f"[wifi] Starting real sniff on interface '{self.interface}' "
              f"(requires monitor mode + root)...")
        sniff(iface=self.interface, prn=self._handle_packet, timeout=timeout)

    # ---- simulated mode ----------------------------------------------------

    def simulate_once(self):
        """Generate one fake device sighting. Call this periodically
        (e.g. once per second) from your main loop to demo the module."""
        fake_mac = ":".join(f"{random.randint(0, 255):02x}" for _ in range(6))
        hashed = hash_mac(fake_mac)
        rssi = random.randint(-90, -30)  # simulated signal strength
        self._record_sighting(hashed, rssi)
        return hashed, rssi

    # ---- shared bookkeeping ------------------------------------------------

    def _record_sighting(self, hashed_mac, rssi=None):
        now = time.time()
        if hashed_mac not in self.seen_devices:
            self.seen_devices[hashed_mac] = {"first_seen": now, "last_seen": now, "count": 1}
        else:
            self.seen_devices[hashed_mac]["last_seen"] = now
            self.seen_devices[hashed_mac]["count"] += 1
        _log_sighting(hashed_mac, rssi)

    def lingering_devices(self, min_seconds=30):
        """
        Devices seen continuously for at least `min_seconds` -- a rough
        proxy for "loitering", which pairs conceptually with the CCTV
        following-behavior alert (e.g. same person's phone lingering
        near a doorway while the camera also flags following behavior).
        """
        now = time.time()
        return {
            mac: info for mac, info in self.seen_devices.items()
            if now - info["first_seen"] >= min_seconds
        }


if __name__ == "__main__":
    # Quick standalone demo: simulate device sightings every second.
    scanner = WifiScanner(simulate=True)
    print(f"[wifi] Logging simulated sightings to {LOG_PATH}. Ctrl+C to stop.")
    try:
        while True:
            mac, rssi = scanner.simulate_once()
            print(f"[wifi] Device seen: {mac} (rssi={rssi})")
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[wifi] Stopped.")
