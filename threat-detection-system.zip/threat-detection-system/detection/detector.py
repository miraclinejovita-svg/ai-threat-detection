"""
detection/detector.py
----------------------
Wraps YOLOv8 (via the `ultralytics` package) to detect people and weapons
(knives) in video frames, and assigns a persistent tracking ID to every
detection using YOLO's built-in ByteTrack tracker.

Why this works without training a custom model:
The COCO dataset (which the stock yolov8n.pt weights are trained on)
already includes both 'person' (class 0) and 'knife' (class 43), so a
lightweight, CPU-friendly pretrained model is enough for this demo.
If you later want better knife-detection accuracy, fine-tune yolov8n on a
custom weapon dataset and swap the model_path.
"""

from ultralytics import YOLO

# COCO class IDs we care about
PERSON_CLASS_ID = 0
KNIFE_CLASS_ID = 43

CLASS_NAMES = {
    PERSON_CLASS_ID: "person",
    KNIFE_CLASS_ID: "knife",
}


class ThreatDetector:
    """Runs YOLOv8 detection + ByteTrack tracking on video frames."""

    def __init__(self, model_path="yolov8n.pt", conf_threshold=0.4):
        """
        model_path: path/name of YOLO weights. 'yolov8n.pt' auto-downloads
                    the nano model (~6MB) on first run -- no GPU required.
        conf_threshold: minimum confidence score to keep a detection.
        """
        print(f"[detector] Loading model '{model_path}' ...")
        self.model = YOLO(model_path)
        self.conf_threshold = conf_threshold
        print("[detector] Model loaded.")

    def detect_and_track(self, frame):
        """
        Run detection + tracking on a single BGR frame (numpy array).

        Returns a list of detection dicts:
            {
              "id": int track id (stable across frames, -1 if untracked),
              "cls": int class id,
              "cls_name": "person" | "knife",
              "conf": float confidence score,
              "bbox": (x1, y1, x2, y2),
              "centroid": (cx, cy)
            }
        """
        results = self.model.track(
            frame,
            persist=True,                # remember IDs between calls
            conf=self.conf_threshold,
            classes=[PERSON_CLASS_ID, KNIFE_CLASS_ID],
            tracker="bytetrack.yaml",    # lightweight tracker, ships with ultralytics
            verbose=False,
        )

        detections = []
        if not results or results[0].boxes is None:
            return detections

        boxes = results[0].boxes
        for box in boxes:
            track_id = int(box.id[0]) if box.id is not None else -1
            cls_id = int(box.cls[0])
            conf = float(box.conf[0])
            x1, y1, x2, y2 = box.xyxy[0].tolist()
            centroid = ((x1 + x2) / 2.0, (y1 + y2) / 2.0)

            detections.append({
                "id": track_id,
                "cls": cls_id,
                "cls_name": CLASS_NAMES.get(cls_id, "unknown"),
                "conf": round(conf, 2),
                "bbox": (int(x1), int(y1), int(x2), int(y2)),
                "centroid": centroid,
            })
        return detections

    def annotate_frame(self, frame, detections, suspicious_ids=None, weapon_present=False):
        """
        Draw bounding boxes + labels on a copy of the frame for display /
        streaming. Suspicious person IDs are drawn in red, weapons in
        orange, everything else in green.
        """
        import cv2
        suspicious_ids = suspicious_ids or set()
        out = frame.copy()

        for det in detections:
            x1, y1, x2, y2 = det["bbox"]
            label = f'{det["cls_name"]} #{det["id"]} {det["conf"]:.2f}'

            if det["cls_name"] == "knife":
                color = (0, 140, 255)  # orange (BGR)
            elif det["id"] in suspicious_ids:
                color = (0, 0, 255)    # red -- suspicious "following" person
            else:
                color = (0, 200, 0)    # green -- normal person

            cv2.rectangle(out, (x1, y1), (x2, y2), color, 2)
            cv2.putText(out, label, (x1, max(y1 - 8, 12)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

        if weapon_present:
            cv2.putText(out, "!!! WEAPON DETECTED !!!", (20, 40),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 3)

        return out
