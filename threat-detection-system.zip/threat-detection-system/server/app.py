"""
server/app.py
--------------
Flask backend that does two things:

1. API: exposes POST /alert -- main.py (or anything else) can POST a JSON
   alert here, and it gets stored + shown on the dashboard.

2. Dashboard: GET / renders a simple HTML page showing:
       - a live annotated camera feed (self-contained: this process runs
         its own detection pipeline for the stream)
       - a live-updating table of recent alerts
       - currently tracked persons

Run this file directly for the full "one command" demo:
    python server/app.py

main.py can also be run separately/instead if you just want the
CLI detection loop without the web dashboard (it will still POST alerts
here if this server is running).
"""

import sys
import os
import time
import threading

import cv2
from flask import Flask, jsonify, request, render_template, Response

# Allow importing sibling packages (detection/, tracking/, behavior/) when
# this file is run directly as `python server/app.py`
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from detection.detector import ThreatDetector
from tracking.tracker import TrackHistory
from behavior.behavior_analyzer import BehaviorAnalyzer

app = Flask(__name__)

# ---- in-memory alert store (fine for a hackathon demo; swap for a DB later) --
alerts_log = []
MAX_ALERTS_STORED = 200

# ---- shared state for the live video feed ------------------------------------
_latest_jpeg = None
_latest_persons = []
_video_lock = threading.Lock()
_pipeline_started = False


@app.route("/alert", methods=["POST"])
def receive_alert():
    """
    Main API endpoint. Accepts a JSON alert, e.g.:
        {
          "type": "WEAPON_PLUS_FOLLOWING",
          "timestamp": 1720000000.0,
          "details": {"person_ids": [2, 5], "knife_conf": 0.81}
        }
    Stores it and returns a JSON acknowledgement.
    """
    data = request.get_json(force=True, silent=True) or {}
    data.setdefault("type", "UNKNOWN")
    data.setdefault("timestamp", time.time())
    data.setdefault("details", {})
    data["received_at"] = time.time()

    alerts_log.append(data)
    if len(alerts_log) > MAX_ALERTS_STORED:
        alerts_log.pop(0)

    print(f"[server] Alert received: {data['type']} -- {data['details']}")
    return jsonify({"status": "ok", "alert_recorded": data}), 200


@app.route("/alerts", methods=["GET"])
def list_alerts():
    """Returns the most recent alerts as JSON, newest first."""
    return jsonify(list(reversed(alerts_log[-50:])))


@app.route("/persons", methods=["GET"])
def list_persons():
    """Returns currently visible person track IDs from the live feed."""
    with _video_lock:
        return jsonify(_latest_persons)


@app.route("/")
def dashboard():
    return render_template("dashboard.html")


@app.route("/video_feed")
def video_feed():
    """MJPEG stream of the annotated camera feed for the dashboard <img> tag."""
    _start_pipeline_once()
    return Response(_mjpeg_generator(), mimetype="multipart/x-mixed-replace; boundary=frame")


def _mjpeg_generator():
    while True:
        with _video_lock:
            frame = _latest_jpeg
        if frame is not None:
            yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + frame + b"\r\n")
        time.sleep(0.03)  # ~30 fps cap


def _start_pipeline_once():
    """Lazily start the background detection thread the first time someone
    loads the video feed, so the webcam isn't opened until it's needed."""
    global _pipeline_started
    if _pipeline_started:
        return
    _pipeline_started = True
    t = threading.Thread(target=_pipeline_loop, daemon=True)
    t.start()


def _pipeline_loop(source=0):
    """
    Runs continuously in a background thread: reads frames from the
    webcam (or RTSP url), detects + tracks people/knives, checks behavior,
    fires alerts, and updates the shared JPEG buffer for /video_feed.
    """
    global _latest_jpeg, _latest_persons

    print("[server] Starting internal detection pipeline for live feed...")
    detector = ThreatDetector(model_path="yolov8n.pt", conf_threshold=0.4)
    history = TrackHistory()
    behavior = BehaviorAnalyzer(distance_threshold=120, frames_required=20)

    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        print("[server] WARNING: could not open camera source; live feed disabled.")
        return

    last_alert_time = 0
    ALERT_COOLDOWN = 8

    while True:
        ok, frame = cap.read()
        if not ok:
            time.sleep(0.5)
            continue

        detections = detector.detect_and_track(frame)
        history.update(detections)
        suspicious_pairs, suspicious_ids = behavior.analyze(detections)

        weapon_detections = [d for d in detections if d["cls_name"] == "knife"]
        weapon_present = len(weapon_detections) > 0

        annotated = detector.annotate_frame(
            frame, detections, suspicious_ids=suspicious_ids, weapon_present=weapon_present
        )

        # Fire an alert if we have a real threat combo, respecting cooldown
        if (weapon_present or suspicious_pairs) and (time.time() - last_alert_time) > ALERT_COOLDOWN:
            alert_type = None
            if weapon_present and suspicious_pairs:
                alert_type = "WEAPON_PLUS_FOLLOWING"
            elif weapon_present:
                alert_type = "WEAPON_DETECTED"
            elif suspicious_pairs:
                alert_type = "FOLLOWING_BEHAVIOR"

            alerts_log.append({
                "type": alert_type,
                "timestamp": time.time(),
                "received_at": time.time(),
                "details": {
                    "suspicious_pairs": list(suspicious_pairs),
                    "weapon_confidences": [d["conf"] for d in weapon_detections],
                },
            })
            if len(alerts_log) > MAX_ALERTS_STORED:
                alerts_log.pop(0)
            last_alert_time = time.time()
            print(f"[server] Internal pipeline alert: {alert_type}")

        ok2, buf = cv2.imencode(".jpg", annotated)
        if ok2:
            with _video_lock:
                _latest_jpeg = buf.tobytes()
                _latest_persons = [
                    {"id": d["id"], "bbox": d["bbox"]}
                    for d in detections if d["cls_name"] == "person"
                ]


if __name__ == "__main__":
    # host="0.0.0.0" so it's reachable from other devices on your network too
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
